# AWS CloudWatch EC2 Monitoring with Terraform

A comprehensive Terraform module for monitoring AWS EC2 instances with CloudWatch alarms, SNS notifications, and dashboards. This project automatically sets up monitoring for multiple EC2 instances based on name tags and provides real-time alerting for critical metrics.

## 🚀 Features

- **Multi-Instance Support**: Automatically discovers and monitors all EC2 instances with matching name tags
- **Comprehensive Monitoring**: CPU, Memory, Disk Space, Network Traffic, and Status Checks
- **Smart Alerting**: Different alert levels (Critical/Warning) with SNS email notifications
- **Visual Dashboards**: Main overview dashboard plus individual instance dashboards
- **Cost Optimized**: Configurable monitoring periods and optional features
- **Production Ready**: Proper validation, error handling, and best practices

## 📊 Monitored Metrics

| Metric | Type | Threshold | Alert Level |
|--------|------|-----------|-------------|
| CPU Utilization | Percentage | 80% | Critical |
| Memory Utilization | Percentage | 85% | Warning |
| Disk Space | Free Space % | 20% | Critical |
| Network Traffic | Bytes/sec | 100MB | Warning |
| Instance Status Check | Pass/Fail | Failed | Critical |
| System Status Check | Pass/Fail | Failed | Critical |

## 🏗️ Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   EC2 Instances │───▶│  CloudWatch      │───▶│ SNS Topics      │
│                 │    │  Metrics & Alarms│    │ - Critical      │
└─────────────────┘    └──────────────────┘    │ - Warning       │
                                ▲               └─────────────────┘
                                │                        │
┌─────────────────┐             │               ┌─────────────────┐
│ CloudWatch      │◀────────────┘               │ Email           │
│ Dashboards      │                             │ Notifications   │
└─────────────────┘                             └─────────────────┘
```

## 🛠️ Prerequisites

- **Terraform**: >= 1.0
- **AWS CLI**: Configured with appropriate credentials
- **AWS Provider**: ~> 5.0
- **Permissions**: EC2, CloudWatch, SNS, and IAM permissions

### Required AWS Permissions

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "ec2:DescribeInstances",
        "cloudwatch:*",
        "sns:*",
        "iam:CreateRole",
        "iam:AttachRolePolicy",
        "iam:CreateInstanceProfile",
        "iam:AddRoleToInstanceProfile"
      ],
      "Resource": "*"
    }
  ]
}
```

## 🚀 Quick Start

1. **Clone the Repository**
   ```bash
   git clone https://github.com/yourusername/aws-cloudwatch-ec2-monitoring.git
   cd aws-cloudwatch-ec2-monitoring
   ```

2. **Configure Variables**
   ```bash
   cp terraform.tfvars.example terraform.tfvars
   # Edit terraform.tfvars with your specific values
   ```

3. **Initialize and Deploy**
   ```bash
   terraform init
   terraform plan
   terraform apply
   ```

4. **Confirm SNS Subscriptions**
   - Check your email for SNS subscription confirmations
   - Click the confirmation links to activate notifications

## ⚙️ Configuration

### Basic Configuration (`terraform.tfvars`)

```hcl
# Basic Settings
aws_region     = "us-east-1"
environment    = "production"
alert_email    = "your-email@company.com"
instance_name  = "your-instance-name"

# Alert Thresholds
cpu_threshold    = 80   # CPU percentage
memory_threshold = 85   # Memory percentage
disk_threshold   = 20   # Free disk space percentage

# Feature Toggles
enable_network_monitoring = false
enable_detailed_monitoring = true
```

### Advanced Configuration

```hcl
# Custom Evaluation Periods
cpu_evaluation_periods    = 2  # 2 periods before alert
memory_evaluation_periods = 2
disk_evaluation_periods   = 1

# Network Monitoring
enable_network_monitoring = true
network_in_threshold = 100000000  # 100MB/s

# Dashboard Settings
dashboard_period_seconds = 300    # 5 minutes
log_group_name = "/aws/ec2/cloudwatch"

# Cost Optimization
alarm_period_seconds = 300        # 5 minute periods
enable_ok_actions = true          # Send OK notifications
```

## 📋 File Structure

```
├── main.tf              # Provider and data sources
├── variables.tf         # Input variable definitions
├── terraform.tfvars     # Variable values (customize this)
├── alerts.tf           # CloudWatch alarms configuration
├── sns.tf              # SNS topics and subscriptions
├── dashboard.tf        # CloudWatch dashboards
├── iam.tf              # IAM roles and policies
├── outputs.tf          # Output definitions
├── README.md           # This file
└── .gitignore          # Git ignore rules
```

## 📊 Dashboards

### Main Dashboard
- Overview of all monitored instances
- CPU, Memory, Disk, and Network metrics
- Status check monitoring
- Error log insights
- Instance information summary

### Per-Instance Dashboards
- Detailed view for each instance (when multiple instances exist)
- Focused metrics for individual troubleshooting

## 🔔 Alert Configuration

### Critical Alerts
- High CPU utilization (>80%)
- Low disk space (<20% free)
- Instance status check failures
- System status check failures

### Warning Alerts
- High memory utilization (>85%)
- High network traffic (>100MB/s)

## 📤 Outputs

After deployment, you'll get:

```hcl
# Dashboard URLs
dashboard_url                = "https://console.aws.amazon.com/cloudwatch/..."
per_instance_dashboard_urls  = ["https://console.aws.amazon.com/..."]

# SNS Information
sns_topic_arns = {
  critical = "arn:aws:sns:us-east-1:123456789:critical-alerts"
  warning  = "arn:aws:sns:us-east-1:123456789:warning-alerts"
}

# Instance Information
monitored_instances = {
  count        = 2
  instance_ids = ["i-1234567890abcdef0", "i-0987654321fedcba0"]
  filter_name  = "nodejs-api-server"
}
```

## 🔧 Customization

### Adding Custom Metrics

1. **Create Custom Alarm in `alerts.tf`:**
   ```hcl
   resource "aws_cloudwatch_metric_alarm" "custom_metric" {
     count = local.instance_count
     
     alarm_name          = "custom-metric-${substr(local.instance_ids[count.index], -8, 8)}"
     comparison_operator = "GreaterThanThreshold"
     evaluation_periods  = "2"
     metric_name         = "YourCustomMetric"
     namespace           = "YourNamespace"
     # ... other configuration
   }
   ```

2. **Add to Dashboard in `dashboard.tf`:**
   ```hcl
   # Add to dashboard widgets array
   {
     type = "metric"
     properties = {
       metrics = [
         for instance_id in data.aws_instances.monitored_instances.ids :
         ["YourNamespace", "YourCustomMetric", "InstanceId", instance_id]
       ]
       # ... other properties
     }
   }
   ```

### Multiple Alert Channels

```hcl
# Add Slack notifications
resource "aws_sns_topic_subscription" "slack_alerts" {
  topic_arn = aws_sns_topic.critical_alerts.arn
  protocol  = "https"
  endpoint  = "https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK"
}
```

## 🚨 Troubleshooting

### Common Issues

1. **No Instances Found**
   ```
   Error: No running instances found with name tag: your-instance-name
   ```
   - Verify your `instance_name` matches the "Name" tag exactly
   - Ensure instances are in "running" state
   - Check AWS region configuration

2. **Memory/Disk Metrics Missing**
   - Install CloudWatch agent on EC2 instances
   - Attach the provided IAM instance profile
   - Configure CloudWatch agent for custom metrics

3. **SNS Subscription Not Confirmed**
   - Check your email spam folder
   - Manually confirm subscription in AWS console
   - Verify email address in `terraform.tfvars`

### CloudWatch Agent Setup

For memory and disk monitoring, install the CloudWatch agent:

```bash
# Amazon Linux 2
sudo yum install amazon-cloudwatch-agent

# Ubuntu
sudo apt-get install amazon-cloudwatch-agent

# Attach the IAM instance profile (output from Terraform)
# Configure agent with custom metrics
```

## 💰 Cost Considerations

- **CloudWatch Alarms**: ~$0.10 per alarm per month
- **Dashboard**: ~$3.00 per dashboard per month
- **SNS**: ~$0.50 per million requests
- **Detailed Monitoring**: ~$2.10 per instance per month (if enabled)

### Cost Optimization Tips

1. **Adjust Monitoring Periods**: Longer periods = fewer data points
2. **Disable OK Actions**: Set `enable_ok_actions = false`
3. **Selective Monitoring**: Use feature toggles to disable unused features
4. **Group Similar Instances**: Use single dashboard for multiple instances

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🏷️ Tags

`terraform` `aws` `cloudwatch` `monitoring` `ec2` `devops` `infrastructure` `alerts` `dashboard` `sns`

## 📞 Support

- Create an [Issue](https://github.com/yourusername/aws-cloudwatch-ec2-monitoring/issues) for bug reports
- Start a [Discussion](https://github.com/yourusername/aws-cloudwatch-ec2-monitoring/discussions) for questions
- Check existing issues before creating new ones

## 🔄 Changelog

### v1.0.0
- Initial release
- Multi-instance support
- Comprehensive monitoring metrics
- Dashboard creation
- SNS alerting
- IAM role management

---

**⭐ If this project helps you, please give it a star!**